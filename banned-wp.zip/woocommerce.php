<?php get_header(); ?>

<div class="content">

    <div class="container">
        <div class="row">

      
            <div class="col-lg-12">

       
            <?php woocommerce_breadcrumb(); ?>


            <?php woocommerce_content(); ?>
            
            </div>

       
      
        
        </div>   
    </div>

</div>

<?php get_footer(); ?>