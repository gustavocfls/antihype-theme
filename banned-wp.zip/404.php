<?php get_header(); ?>

<div class="container">
    <h1>Página não encontrada.</h1>
</div>

<?php get_footer(); ?>